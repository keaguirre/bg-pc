# Contribution

- Please include both 4k and 1080p variants of your wallpaper in the respective folder.
- Also please make sure that both the 4k and 1080p variants of your wallpaper have the exact same name as it is required for the website to fetch them correctly.
