This repository (with exceptions of files mentioned below) is licensed under CC BY-SA 4.0.

#### [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/)

### Files not included in the license -

| File                          | Original Author                           | License |
| ----------------------------- | ----------------------------------------- | ------- |
| Arch Linux (Logo Rainbow).png | [DustVoice](https://github.com/DustVoice) | -       |
| Kraken.png                    | -                                         | -       |
| Ship.png                      | -                                         | -       |
